

global  _main
extern  _printf
extern  _scanf
extern  _ExitProcess@4

section .bss
character:     resd 1

section .data
prompt: db 'Enter an ASCII character: ',0
output: db 'The user entered the character %c which is decimal %d in the ASCII table', 0ah,0
frmt:   db '%c',0
greet:  db 'Hello, %s!',0ah,0

section .text
_main:
       
	    ; prompt the user

		; use scanf to get the value from the user
		
		; print the value 

		; exit the program
		xor    ecx, ecx
