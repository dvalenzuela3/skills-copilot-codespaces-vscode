

global  _main
extern  _ExitProcess@4

section .bss
byteCount: resd 1

section .data
message:	db 'I Love Assembly Language!!'
messageEnd: db 1

section .text
_main:
       
		; exit the program
		xor    ecx, ecx
        call    _ExitProcess@4