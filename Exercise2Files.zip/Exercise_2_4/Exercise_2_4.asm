

global  _main
extern  _printf
extern  _scanf
extern  _ExitProcess@4

section .bss

section .data

section .text
_main:
       

		; exit the program
		xor    ecx, ecx
        call    _ExitProcess@4